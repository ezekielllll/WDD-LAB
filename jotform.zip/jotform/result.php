<?php
if(isset($_POST['submit'])){
    $fName = $_POST['fName'];
    $lName = $_POST['lName'];
    $addrOne = $_POST['addrOne'];
    $addrTwo = $_POST['addrTwo'];
    $addrCity = $_POST['addrCity'];
    $addrState = $_POST['addrState'];
    $addrPostal = $_POST['addrPostal'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $how = $_POST['how'];
    $otherSpec = $_POST['otherSpec'];
    $feedback = $_POST['feedback'];
    $suggestion = $_POST['suggestion'];
    $recommend = $_POST['recommend'];
    $refNameOne = $_POST['refNameOne'];
    $refAddrOne = $_POST['refAddrOne'];
    $refNumOne = $_POST['refNumOne'];
    $refNameTwo = $_POST['refNameTwo'];
    $refAddrTwo = $_POST['refAddrTwo'];
    $refNumTwo = $_POST['refNumTwo'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Result</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body style="background-color:#f3f3fe;">
<div class="d-flex justify-content-center" style="width:100%">
    <div class="container-xxl rounded m-4 bg-light shadow">
        <h1 class="text-center p-3 fw-bold">Result</h1><hr>
        <div class="d-flex gap-3">
            <div class="my-3" style="width:100%">
                <p>Firstname</p>
                <input type="text" class="form-control" value="<?php echo $fName?>" readonly>
            </div>
            <div class="my-3" style="width:100%">
                <p>Lastname</p>
                <input type="text" class="form-control" value="<?php echo $lName?>" readonly>
            </div>
        </div>
        <div class="my-3">
            <p>Address Line 1</p>
            <input type="text" class="form-control" value="<?php echo $addrOne?>" readonly>
        </div>
        <?php if($addrTwo != ''){ ?>
        <div class="my-3">
            <p>Address Line 2</p>
            <input type="text" class="form-control" value="<?php echo $addrTwo?>" readonly>
        </div>
        <?php } ?>
        <div class="d-flex gap-3">
            <?php if($addrCity != ''){ ?>
            <div class="my-3" style="width:100%">
                <p>City</p>
                <input type="text" class="form-control" value="<?php echo $addrCity?>" readonly>
            </div>
            <?php } ?>
            <?php if($addrState != ''){ ?>
            <div class="my-3" style="width:100%">
                <p>Province</p>
                <input type="text" class="form-control" value="<?php echo $addrState?>"readonly>
            </div>
            <?php } ?>
        </div>
        <?php if($addrPostal != ''){ ?>
        <div class="my-3">
            <p>Postal Code</p>
            <input type="text" class="form-control" value="<?php echo $addrPostal?>" readonly>
        </div>
        <?php } ?>
        <div class="d-flex gap-3">
            <div class="my-3" style="width:100%">
                <p>Phone Number</p>
                <input type="text" class="form-control" value="<?php echo $phone?>" readonly>
            </div>
            <?php if($email != ''){ ?>
            <div class="my-3" style="width:100%">
                <p>E-Mail</p>
                <input type="text" class="form-control" value="<?php echo $email?>" readonly>
            </div>
            <?php } ?>
        </div>
        <div class="d-flex gap-3">
            <div class="my-3" style="width:100%">
                <p>How did you hear about us?</p>
                <input type="text" class="form-control" value="<?php echo $how?>" readonly>
            </div>
            <?php if($otherSpec != ''){ ?>
            <div class="my-3" style="width:100%">
                <p>Please specify:</p>
                <input type="text" class="form-control" value="<?php echo $otherSpec?>" readonly>
            </div>
            <?php } ?>
        </div>
        <?php if($feedback != ''){ ?>
        <div class="my-3">
            <p>Feedback about us:</p>
            <input type="text" class="form-control" value="<?php echo $feedback?>" readonly>
        </div>
        <?php } ?>
        <?php if($suggestion != ''){ ?>
        <div class="my-3">
            <p>Suggestions if any for further improvement:</p>
            <input type="text" class="form-control" value="<?php echo $suggestion?>" readonly>
        </div>
        <?php } ?>
        <?php if($recommend != ''){ ?>
        <div class="my-3">
            <p>Will you be willing to recommend us?</p>
            <input type="text" class="form-control" value="<?php echo $recommend?>" readonly>
        </div>
        <?php } ?>
        <p>Please give reference of any two people whom you feel:</p>
        <?php if($refNameOne != '' && $refAddrOne != '' && $refNumOne != ''){ ?>
        <hr>
        <p>Person 1</p>
        <div class="d-flex gap-3">
            <div class="my-3" style="width:100%">
                <p>Fullaname</p>
                <input type="text" class="form-control" value="<?php echo $refNameOne?>" readonly>
            </div>
            <div class="my-3" style="width:100%">
                <p>Address</p>
                <input type="text" class="form-control" value="<?php echo $refAddrOne?>" readonly>
            </div>
            <div class="my-3" style="width:100%">
                <p>Contact Number</p>
                <input type="text" class="form-control" value="<?php echo $refNumOne?>" readonly>
            </div>
        </div>
        <?php } ?>
        <?php if($refNameTwo != '' && $refAddrTwo != '' && $refNumTwo != ''){ ?>
        <hr>
        <p>Person 2</p>
        <div class="d-flex gap-3">
            <div class="my-3" style="width:100%">
                <p>Fullaname</p>
                <input type="text" class="form-control" value="<?php echo $refNameTwo?>" readonly>
            </div>
            <div class="my-3" style="width:100%">
                <p>Address</p>
                <input type="text" class="form-control" value="<?php echo $refAddrTwo?>" readonly>
            </div>
            <div class="my-3" style="width:100%">
                <p>Contact Number</p>
                <input type="text" class="form-control" value="<?php echo $refNumTwo?>" readonly>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
</body>
</html>